To install

python setup.py install
